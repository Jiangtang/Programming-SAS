proc groovy;
submit parseonly;

import org.xml.sax.ErrorHandler
import static javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI
import javax.xml.transform.stream.StreamSource
import javax.xml.validation.Schema
import javax.xml.validation.SchemaFactory
import javax.xml.validation.Validator

/**
 * Groovy class to validate an XML file against a W3C XML Schema.
 */
public class ValidateXML {


/**
 * Method to validate an XML file against a W3C XML Schema.
 *
 * @param xmlFile Full path to the XML file to validate.
 * @param xsdFile Full path to the W3C XML Schema file to validate against.
 *
 */

   public void validateXML(String xmlFile, String xsdFile) {
    SchemaFactory factory = SchemaFactory.newInstance( W3C_XML_SCHEMA_NS_URI )
    Schema schema = factory.newSchema( new StreamSource( xsdFile ) )
    Validator validator = schema.newValidator()
    
    List exceptions = []
    Closure<Void> handler = { exception -> exceptions << exception }
    validator.errorHandler = [ warning:    handler,
                               fatalError: handler,
                               error:      handler ] as ErrorHandler

    println "NOTE: [CSTLOG"+"MESSAGE] Validating $xmlFile".trim() + " " + "against $xsdFile".trim()
    try {
    validator.validate( new StreamSource( xmlFile ) )
    } catch (Exception e) {
      println "ERROR [CSTLOG" + "MESSAGE] "+ "${e.message}."
    } 
    exceptions.each {
      println "ERROR: [CSTLOG"+"MESSAGE]line $it.lineNumber, col $it.columnNumber : $it.message"
    }
   
  }
}

endsubmit;
quit;
