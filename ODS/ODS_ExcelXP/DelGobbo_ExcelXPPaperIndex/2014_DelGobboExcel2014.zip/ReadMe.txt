Contents:
========

This ZIP archive contains the following files:

Exercise1.sas - Create initial multi-sheet workbook.

Exercise2.sas - Use BY group values for worksheet names.

Exercise3.sas - Suppress BY line text and embed title text into the workbook.

Exercise4.sas - Automatically convert SAS datetime values to Excel datetime values.

Exercise5.sas - Apply an Excel number format to change the display of the datetime values.

Setup.sas - Sets up the SAS operating environment.

Solution2.sas - Solution to Exercise 2.

Solution3.sas - Solution to Exercise 3.

Solution4.sas - Solution to Exercise 4.

Solution5.sas - Solution to Exercise 5.

ReadMe.txt - This file.

Documentation - ExcelXP Tagset Help v1.116.pdf - ExcelXP tagset documentation.

Handouts - 2014 Excel Basics Beyond Part 1.pdf - PDF version of the handouts for the workshop.

Paper - 2014 Excel Basics Beyond Part 1.pdf - PDF version of the paper.


Installation:
============

The sample SAS code assumes that you have extracted the archive into the directory "C:\HOW\DelGobbo\".  If you extract this archive to a different directory, you must to modify the value of the SAMPDIR macro variable in the Setup.sas file.

Additionally, all SAS output is written to this directory.


Usage:
=====

Start SAS and submit Setup.sas, followed by the other files of interest.