Contents:
========

This ZIP archive contains the following files:

Paper - Multisheet Excel.pdf - PDF version of the paper "Creating AND Importing Multi-Sheet Excel Workbooks the Easy Way with SAS", presented at the 31st SAS Users Group International Conference (SUGI), March 26-29, 2006.

Handouts.pdf - PDF version of the handouts for the workshop "Creating AND Importing Multi-Sheet Excel Workbooks the Easy Way with SAS", presented at the 31st SAS Users Group International Conference (SUGI), March 26-29, 2006.

AEData.sas7bdat - sample SAS table with adverse event information.

DataToImport.xls - sample multi-sheet Excel workbook.

ExcelXP.sas - recent version of the ExcelXP ODS tagset.

ExcelXP.map - SAS XMLMap used to read Excel XML files into SAS tables (used by "LoadXL.sas").

LoadXL.sas - contains the XLXP2SAS SAS macro, which reads Excel XML workbooks into SAS tables.

CompleteCode.sas - complete sample code used in the hands-on workshop "Creating AND Importing Multi-Sheet Excel Workbooks the Easy Way with SAS".

Setup.sas - sets up the SAS operating environment.

MakeXML.sas - first attempt at making an XML file for Excel.

MakeXML-Fix1.sas - Correct missing leading zeroes using a style override and Excel format.

MakeXML-Fix2.sas - Add custom worksheet names using a tagset option.

MakeXML-Fix3.sas - Adjust column widths in PRINT output, part 1 (label and split character).

MakeXML-Fix4.sas - Adjust column widths in PRINT output, part 2 (tagset option).

MakeXML-Fix5.sas - Change BY group placement using the NOCENTER system option.

MakeXML-Fix6.sas - Adjust column widths in TABULATE output using a tagset option.

MakeXML-Fix7.sas - Freeze column headers when scrolling and add AutoFilters using tagset options.

MakeXML-Fix8.sas - Control print orientation and repating rows in printed output using tagset options.

MakeXML-Fix9.sas - Add custom headers and footers to printed output using tagset options.

ReadXML.sas - import the Excel XML data from local file system to SAS tables.

ReadMe.txt - this file.

Documentation - ExcelXP Tagset.pdf - ExcelXP tagset documentation.

Article - Beginner Office.pdf - PDF version of the November 2003 news article "A Beginner's Guide to Incorporating SAS Output in Microsoft Office Applications".

Article - Excel XML.pdf - PDF version of the July 2004 news article "New Techniques for Transferring Data and Results between SAS and Excel".

Article - Moving Data.pdf - PDF version of the July 2005 news article "Moving Data and Analytical Results between SAS and Microsoft Office".

Paper - Beginners Office.pdf - PDF version of the paper "A Beginner's Guide to Incorporating SAS Output in Microsoft Office Applications".

Paper - Cross Platform Office.pdf - PDF version of the paper "Techniques for SAS Enabling Microsoft Office in a Cross-Platform Environment".

Paper - Excel XML.pdf - PDF version of the paper "From SAS to Excel via XML".

Paper - Moving Data.pdf - PDF version of the paper "Moving Data and Analytical Results between SAS and Microsoft Office".


Installation:
============

The sample SAS code assumes that you have unpacked the archive into the directory "c:\workshop\ws115\".  If you unpack
this archive to a different directory, you will need to modify the value of the SAMPDIR macro variable in the files:

Setup.sas
CompleteCode.sas

Additionally, all SAS output will be written to this directory.


Usage:
=====

Start SAS and submit CompleteCode.sas to execute all the sample code.  Alternatively, you can submit Setup.sas,
followed by the other files of interest.