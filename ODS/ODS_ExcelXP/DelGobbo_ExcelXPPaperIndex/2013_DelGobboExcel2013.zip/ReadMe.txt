Contents:
========

This ZIP archive contains the following files:

Exercise1.sas - Create CSV files using PROC EXPORT, and import to Excel.

Exercise2.sas - Create CSV files using the ODS CSVALL destination, and import to Excel.

Exercise3.sas - Create Multi-sheet ExcelXP XML workbook.

Exercise4.sas - Regroup worksheets, and change worksheet names in ExcelXP XML workbook.

Exercise5.sas - Suppress BY-line text and embed title text into ExcelXP XML workbook.

Exercise6.sas - Apply an Excel number format in the ExcelXP XML workbook.

Setup.sas - Sets up the SAS operating environment.

Solution2.sas - Solution to Exercise 2.

Solution4.sas - Solution to Exercise 4.

Solution5.sas - Solution to Exercise 5.

Solution6.sas - Solution to Exercise 6.

ReadMe.txt - This file.

Documentation - ExcelXP Tagset Help v1.116.pdf - ExcelXP tagset documentation.

Handouts - 2013 Excel Techniques.pdf - PDF version of the handouts for the workshop "Some Techniques for Integrating SAS Output with Microsoft Excel Using Base SAS".

Paper - 2013 Excel Techniques.pdf - PDF version of the paper "Some Techniques for Integrating SAS Output with Microsoft Excel Using Base SAS".

Content.MSO.lnk - Microsoft Windows shortcut to the directory containing the Excel error log.


Installation:
============

The sample SAS code assumes that you have extracted the archive into the directory "C:\HOW\DelGobbo\".  If you extract this archive to a different directory, you must to modify the value of the SAMPDIR macro variable in the Setup.sas file.

Additionally, all SAS output is written to this directory.


Usage:
=====

Start SAS and submit Setup.sas, followed by the other files of interest.