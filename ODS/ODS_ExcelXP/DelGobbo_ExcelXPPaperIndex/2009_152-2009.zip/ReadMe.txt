Contents:
========

This ZIP archive contains the following files:

Paper - 2009 Multisheet Excel.pdf - PDF version of the paper "More Tips and Tricks for Creating Multi-Sheet Excel Workbooks the Easy Way with SAS".

2009 Handouts.pdf - PDF version of the handouts for the workshop "More Tips and Tricks for Creating Multi-Sheet Excel Workbooks the Easy Way with SAS".

DrugApprovals.sas7bdat - sample SAS table with financial information.

ExcelXP.sas - recent version of the ExcelXP ODS tagset.

CompleteCode.sas - complete sample code used in the hands-on workshop "More Tips and Tricks for Creating Multi-Sheet Excel Workbooks the Easy Way with SAS".

Setup.sas - sets up the SAS operating environment.

MakeXML.sas - first attempt at making an XML file for Excel.

MakeXML-Fix1.sas - Center the text in the "Rating" column using style overrides.

MakeXML-Fix2.sas - "Convert" SAS dates to Excel dates using style overrides.

MakeXML-Fix3.sas - Add an Excel formula and Excel format to the "ReviewTime" column using style overrides.

MakeXML-Fix4.sas - Get the TITLE text into the worksheets using tagset options.

MakeXML-Fix5.sas - Name the worksheets according to the BY group values using tagset options.

MakeXML-Fix6.sas - Create narrow columns with wrapped text using tagset options.

ReadMe.txt - this file.

Documentation - ExcelXP Tagset Help v1.94.pdf - ExcelXP tagset documentation.

Article - Beginner Office.pdf - PDF version of the November 2003 news article "A Beginner's Guide to Incorporating SAS Output in Microsoft Office Applications".

Article - Creating AND Importing.pdf - PDF version of the August 2006 news article "Creating AND Importing Multi-Sheet Excel Workbooks the Easy Way with SAS".

Article - Excel XML.pdf - PDF version of the July 2004 news article "New Techniques for Transferring Data and Results between SAS and Excel".

Article - Moving Data.pdf - PDF version of the July 2005 news article "Moving Data and Analytical Results between SAS and Microsoft Office".

Paper - 2006 Multisheet Excel.pdf - PDF version of the paper "Creating AND Importing Multi-Sheet Excel Workbooks the Easy Way with SAS".

Paper - 2007 Multisheet Excel.pdf - PDF version of the paper "Creating Multi-Sheet Excel Workbooks the Easy Way with SAS".

Paper - 2008 Multisheet Excel.pdf - PDF version of the paper "Tips and Tricks for Creating Multi-Sheet Excel Workbooks the Easy Way with SAS".

Paper - Beginners Office.pdf - PDF version of the paper "A Beginner's Guide to Incorporating SAS Output in Microsoft Office Applications".

Paper - Cross Platform Office.pdf - PDF version of the paper "Techniques for SAS Enabling Microsoft Office in a Cross-Platform Environment".

Paper - Excel XML.pdf - PDF version of the paper "From SAS to Excel via XML".

Paper - Moving Data.pdf - PDF version of the paper "Moving Data and Analytical Results between SAS and Microsoft Office".


Installation:
============

The sample SAS code assumes that you have unpacked the archive into the directory "C:\HOW\DelGobbo\".  If you unpack this archive to a different directory, you will need to modify the value of the SAMPDIR macro variable in the files:

Setup.sas
CompleteCode.sas

Additionally, all SAS output will be written to this directory.


Usage:
=====

Start SAS and submit CompleteCode.sas to execute all the sample code.  Alternatively, you can submit Setup.sas, followed by the other files of interest.