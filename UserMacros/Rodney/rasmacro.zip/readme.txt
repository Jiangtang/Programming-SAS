RASmacro installation

1. unzip them into a directory denoted by ?????? (use the actual name)

2. edit your SAS configuration file, sasv8.cfg or sasv9_local.cfg

2a. you probably have a line something like the following:

-sasautos '!SASROOT/sasautos'                     /* for Unix/Linux */

-sasautos '!SASROOT\core\sasmacro'                /* for Windows    */

2b. edit or add the corresponding line as follows:

-sasautos ( '!SASROOT/sasautos' '??????' )        /* for Unix/Linux */

-sasautos ( '!SASROOT\core\sasmacro' '??????' )   /* for Windows    */

